import { Heading, HStack, Image, Text, VStack, Box } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const projects = [
  {
    title: "React Space",
    description:
      "Handy tool belt to create amazing AR components in a React app, with redux integration via middleware️",
    imageSrc: require("../images/photo1.jpg"), // Directly store the require result
  },
  {
    title: "React Infinite Scroll",
    description:
      "A scrollable bottom sheet with virtualisation support, native animations at 60 FPS and fully implemented in JS land 🔥️",
    imageSrc: require("../images/photo2.jpg"),
  },
  {
    title: "Photo Gallery",
    description:
      "A One-stop shop for photographers to share and monetize their photos, allowing them to have a second source of income",
    imageSrc: require("../images/photo3.jpg"),
  },
  {
    title: "Event planner",
    description:
      "A mobile application for leisure seekers to discover unique events and activities in their city with a few taps",
    imageSrc: require("../images/photo4.jpg"),
  },
];

const Card = ({ title, description, imageSrc }) => {
  return (
    <Box
      borderRadius="lg"
      overflow="hidden"
      bg="white"
      boxShadow="md"
      p={4}
    >
      <VStack align="start" spacing={4}>
        <Image src={imageSrc} alt={title} borderRadius="md" />
        <Heading size="md" color="black">{title}</Heading> {/* Title is black */}
        <Text color="black">{description}</Text> {/* Description is black */}
        <HStack alignSelf="flex-end">
          <Text fontWeight="bold" color="teal.500"> {/* "See More" remains teal */}
            See More
          </Text>
          <FontAwesomeIcon icon={faArrowRight} color="teal.500" size="1x" /> {/* Icon is teal */}
        </HStack>
      </VStack>
    </Box>
  );
};

export default Card;
